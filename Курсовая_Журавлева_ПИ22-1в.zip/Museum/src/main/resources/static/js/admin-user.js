document.addEventListener("DOMContentLoaded", function() {
    // Обработчик кнопки "Сделать Админом"
    document.querySelectorAll('.make-admin-btn').forEach(function(button) {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-id');
            if (confirm("Вы уверены, что хотите назначить этого пользователя администратором?")) {
                fetch(`/admin/users/${userId}/make-admin`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                        // CSRF-токен не нужен, так как CSRF-защита отключена
                    }
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Сетевая ошибка');
                        }
                        return response.json();
                    })
                    .then(data => {
                        alert(data.message);
                        if (data.message === "Пользователь назначен администратором") {
                            location.reload();
                        }
                    })
                    .catch(error => {
                        console.error('Ошибка:', error);
                        alert("Произошла ошибка при назначении администратора.");
                    });
            }
        });
    });

    // Обработчик кнопки "Удалить"
    document.querySelectorAll('.delete-user-btn').forEach(function(button) {
        button.addEventListener('click', function() {
            const userId = this.getAttribute('data-id');
            if (confirm("Вы уверены, что хотите удалить этого пользователя?")) {
                fetch(`/admin/users/${userId}`, {
                    method: 'DELETE',
                    headers: {
                        'Content-Type': 'application/json'
                        // CSRF-токен не нужен, так как CSRF-защита отключена
                    }
                })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Сетевая ошибка');
                        }
                        return response.json();
                    })
                    .then(data => {
                        alert(data.message);
                        if (data.message === "Пользователь успешно удалён") {
                            // Удалить строку из таблицы
                            this.closest('tr').remove();
                        }
                    })
                    .catch(error => {
                        console.error('Ошибка:', error);
                        alert("Произошла ошибка при удалении пользователя.");
                    });
            }
        });
    });
});
