package org.example.Museum.repository;

import org.example.Museum.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {
    List<Customer> findByTicketContainingIgnoreCase(String ticket);
    List<Customer> findByVisitorContainingIgnoreCase(String visitor);
}
