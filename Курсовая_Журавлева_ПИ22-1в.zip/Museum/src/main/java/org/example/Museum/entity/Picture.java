package org.example.Museum.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "pictures")
public class Picture {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Номер зала не должен быть пустым")
    private String hall;

    @NotBlank(message = "Имя автора не должно быть пустым")
    private String author;

    @NotBlank(message = "Название картины не должно быть пустым")
    private String name;

    @NotBlank(message = "Год написания картины не должен быть пустым")
    private String year;

    // Конструкторы
    public Picture() {}

    public Picture(String hall, String author, String name, String year) {
        this.hall = hall;
        this.author = author;
        this.name = name;
        this.year = year;
    }

    // Геттеры и Сеттеры
    public Long getId() {
        return id;
    }

    public String getHall() {
        return hall;
    }

    public void setHall(String hall) {
        this.hall = hall;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public void setId(long id) {
        this.id = id;
    }
}
