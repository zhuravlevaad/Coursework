package org.example.Museum.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDateTime;

@Entity
@Table(name = "customers")
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Номер билета не должен быть пустым")
    private String ticket;

    @NotBlank(message = "Название выставки не должно быть пустым")
    private String exhibition;

    @NotBlank(message = "Имя посетителя не должно быть пустым")
    private String visitor;

    @NotNull(message = "Дата покупки билета не должна быть пустой")
    private LocalDateTime purchase;

    @NotNull(message = "Дата посещения не должна быть пустой")
    private LocalDateTime visit;

    // Дополнительные поля для форматированных дат (Transient)
    @Transient
    private String formattedPurchase;

    @Transient
    private String formattedVisit;

    // Конструкторы
    public Customer() {}

    public Customer(String ticket, String exhibition, String visitor, LocalDateTime purchase, LocalDateTime visit) {
        this.ticket = ticket;
        this.exhibition = exhibition;
        this.visitor = visitor;
        this.purchase = purchase;
        this.visit = visit;
    }

    // Геттеры и Сеттеры
    public Long getId() {
        return id;
    }

    public String getTicket() {
        return ticket;
    }

    public void setTicket(String ticket) {
        this.ticket = ticket;
    }

    public String getExhibition() {
        return exhibition;
    }

    public void setExhibition(String exhibition) {
        this.exhibition = exhibition;
    }

    public String getVisitor() {
        return visitor;
    }

    public void setVisitor(String visitor) {
        this.visitor = visitor;
    }

    public LocalDateTime getPurchase() {
        return purchase;
    }

    public void setPurchase(LocalDateTime purchase) {
        this.purchase = purchase;
    }

    public LocalDateTime getVisit() {
        return visit;
    }

    public void setVisit(LocalDateTime visit) {
        this.visit = visit;
    }

    public String getFormattedPurchase() {
        return formattedPurchase;
    }

    public void setFormattedPurchase(String formattedPurchase) {
        this.formattedPurchase = formattedPurchase;
    }

    public String getFormattedVisit() {
        return formattedVisit;
    }

    public void setFormattedVisit(String formattedVisit) {
        this.formattedVisit = formattedVisit;
    }

    public void setId(long id) {
        this.id = id;
    }
}

