package org.example.Museum.config;

import org.example.Museum.service.CustomUserDetailsService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;

    public SecurityConfig(CustomUserDetailsService userDetailsService){
        this.userDetailsService = userDetailsService;
    }

    // Бин для кодирования паролей
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // Бин для аутентификационного провайдера
    @Bean
    public DaoAuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
        authProvider.setUserDetailsService(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    // Бин для SecurityFilterChain
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http, AuthenticationConfiguration authConfig) throws Exception {
        // Получаем AuthenticationManager из AuthenticationConfiguration
        AuthenticationManager authManager = authConfig.getAuthenticationManager();

        // Создаём экземпляр кастомного фильтра и передаём ему AuthenticationManager
        JsonUsernamePasswordAuthenticationFilter jsonAuthFilter = new JsonUsernamePasswordAuthenticationFilter(authManager);
        jsonAuthFilter.setFilterProcessesUrl("/api/login"); // Новый URL для AJAX входа

        http
                // Устанавливаем аутентификационный провайдер
                .authenticationProvider(authenticationProvider())

                // Настройка авторизации запросов
                .authorizeHttpRequests(authorize -> authorize
                        // Разрешить доступ к статическим ресурсам, страницам входа, регистрации и ошибкам
                        .requestMatchers("/css/**", "/js/**", "/images/**", "/register", "/login", "/error/**").permitAll()
                        // Разрешить доступ к административным URL только пользователям с ролью ADMIN
                        .requestMatchers("/admin/**").hasRole("ADMIN")
                        // Разрешить доступ к блогу всем аутентифицированным пользователям
                        .requestMatchers("/blog/**").authenticated()
                        // Все остальные запросы требуют аутентификации
                        .anyRequest().authenticated()
                )

                // Добавляем кастомный фильтр перед стандартным фильтром аутентификации
                .addFilterAt(jsonAuthFilter, UsernamePasswordAuthenticationFilter.class)

                // Настройка формы входа
                .formLogin(form -> form
                        .loginPage("/login")
                        .defaultSuccessUrl("/cargos", true)
                        .permitAll()
                )

                // Настройка выхода из системы
                .logout(logout -> logout
                        .permitAll()
                )

                // Управление сессиями
                .sessionManagement(session -> session
                        .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                )

                // Отключить CSRF для простоты (не рекомендуется для продакшена)
                .csrf(csrf -> csrf.disable());

        return http.build();
    }
}
