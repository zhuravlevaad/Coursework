package org.example.Museum.repository;

import org.example.Museum.entity.Exhibition;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ExhibitionRepository extends JpaRepository<Exhibition, Long> {
    List<Exhibition> findByNameContainingIgnoreCase(String name);
    List<Exhibition> findByCuratorContainingIgnoreCase(String curator);
}

