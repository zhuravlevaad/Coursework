package org.example.Museum.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

@Entity
@Table(name = "exhibitions")
public class Exhibition {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Номер зала не должен быть пустым")
    private String hall;

    @NotBlank(message = "Название выставки не должно быть пустым")
    private String name;

    @NotNull(message = "Дата начала не должна быть пустой")
    private LocalDate startdate;

    @NotNull(message = "Дата окончания не должна быть пустой")
    private LocalDate finishdate;

    @NotBlank(message = "Имя куратора не должно быть пустым")
    private String curator;

    @NotBlank(message = "Имена авторов не должны быть пустыми")
    private String authors;

    // Дополнительные поля для форматированных дат (Transient)
    @Transient
    private String formattedStartdate;

    @Transient
    private String formattedFinishdate;

    // Конструкторы
    public Exhibition() {}

    public Exhibition(String hall, String name, LocalDate startdate, LocalDate finishdate, String curator, String authors) {
        this.hall = hall;
        this.name = name;
        this.startdate = startdate;
        this.finishdate = finishdate;
        this.curator = curator;
        this.authors = authors;
    }

    // Геттеры и Сеттеры
    public Long getId() {
        return id;
    }

    public String getHall() {
        return hall;
    }

    public void setHall(String hall) {
        this.hall = hall;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getStartdate() {
        return startdate;
    }

    public void setStartdate(LocalDate startdate) {
        this.startdate = startdate;
    }

    public LocalDate getFinishdate() {
        return finishdate;
    }

    public void setFinishdate(LocalDate finishdate) {
        this.finishdate = finishdate;
    }

    public String getFormattedStartdate() {
        return formattedStartdate;
    }

    public void setFormattedStartdate(String formattedStartdate) {
        this.formattedStartdate = formattedStartdate;
    }

    public String getFormattedFinishdate() {
        return formattedFinishdate;
    }

    public void setFormattedFinishdate(String formattedFinishdate) {
        this.formattedFinishdate = formattedFinishdate;
    }

    public String getCurator() {
        return curator;
    }

    public void setCurator(String curator) {
        this.curator = curator;
    }

    public String getAuthors() {
        return authors;
    }

    public void setAuthors(String authors) {
        this.authors = authors;
    }

    public void setId(long id) {
        this.id = id;
    }
}
