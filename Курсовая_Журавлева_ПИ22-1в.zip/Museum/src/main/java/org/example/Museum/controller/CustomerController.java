package org.example.Museum.controller;

import jakarta.validation.Valid;
import org.example.Museum.entity.Customer;
import org.example.Museum.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/customers")
public class CustomerController {

    private final CustomerRepository customerRepository;

    @Autowired
    public CustomerController(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @GetMapping
    public String listCustomers(Model model,
                                @RequestParam(value = "search", required = false) String search,
                                @RequestParam(value = "filter", required = false) String filter,
                                @RequestParam(value = "service", required = false) String service) {
        List<Customer> customers;

        // Поиск по различным параметрам
        if (search != null && !search.isEmpty()) {
            customers = customerRepository.findByTicketContainingIgnoreCase(search);
        } else if (service != null && !service.isEmpty()) {
            customers = customerRepository.findByVisitorContainingIgnoreCase(service);
        } else {
            customers = customerRepository.findAll();
        }

        // Форматирование дат
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");
        for (Customer customer : customers) {
            customer.setFormattedPurchase(customer.getPurchase().format(formatter));
            customer.setFormattedVisit(customer.getVisit().format(formatter));
        }

        model.addAttribute("customers", customers);
        return "customers";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("customer", new Customer());
        return "add-customer";
    }

    @PostMapping("/add")
    public String addCustomer(@Valid @ModelAttribute("customer") Customer customer, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-customer";
        }
        customerRepository.save(customer);
        return "redirect:/customers";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID посетителя: " + id));
        model.addAttribute("customer", customer);
        return "edit-customer";
    }

    @PostMapping("/update/{id}")
    public String updateCustomer(@PathVariable("id") long id, @Valid @ModelAttribute("customer") Customer customer,
                                 BindingResult result, Model model) {
        if (result.hasErrors()) {
            customer.setId(id);
            return "edit-customer";
        }

        Customer existingCustomer = customerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID посетителя: " + id));

        existingCustomer.setTicket(customer.getTicket());
        existingCustomer.setExhibition(customer.getExhibition());
        existingCustomer.setVisitor(customer.getVisitor());
        existingCustomer.setPurchase(customer.getPurchase());
        existingCustomer.setVisit(customer.getVisit());

        customerRepository.save(existingCustomer);
        return "redirect:/customers";
    }

    @GetMapping("/delete/{id}")
    public String deleteCustomer(@PathVariable("id") long id, Model model) {
        Customer customer = customerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID посетителя: " + id));
        customerRepository.delete(customer);
        return "redirect:/customers";
    }
}
