package org.example.Museum.repository;

import org.example.Museum.entity.Picture;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PictureRepository extends JpaRepository<Picture, Long> {
    List<Picture> findByAuthorContainingIgnoreCase(String author);
    List<Picture> findByNameContainingIgnoreCase(String name);
}
