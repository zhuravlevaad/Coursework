package org.example.Museum.controller;

import jakarta.validation.Valid;
import org.example.Museum.entity.Picture;
import org.example.Museum.repository.PictureRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/pictures")
public class PictureController {

    @Autowired
    private PictureRepository pictureRepository;

    @GetMapping
    public String listPictures(Model model,
                               @RequestParam(value = "search", required = false) String search,
                               @RequestParam(value = "filter", required = false) String filter,
                               @RequestParam(value = "service", required = false) String service) {
        List<Picture> pictures;

        // Поиск по различным параметрам
        if (search != null && !search.isEmpty()) {
            pictures = pictureRepository.findByAuthorContainingIgnoreCase(search);
        } else if (service != null && !service.isEmpty()) {
            pictures = pictureRepository.findByNameContainingIgnoreCase(service);
        } else {
            pictures = pictureRepository.findAll();
        }

        model.addAttribute("pictures", pictures);
        return "pictures";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("picture", new Picture());
        return "add-picture";
    }

    @PostMapping("/add")
    public String addPicture(@Valid @ModelAttribute("picture") Picture picture, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-picture";
        }
        pictureRepository.save(picture);
        return "redirect:/pictures";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Picture picture = pictureRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID картины: " + id));
        model.addAttribute("picture", picture);
        return "edit-picture";
    }

    @PostMapping("/update/{id}")
    public String updatePicture(@PathVariable("id") long id, @Valid @ModelAttribute("picture") Picture picture,
                                BindingResult result, Model model) {
        if (result.hasErrors()) {
            picture.setId(id);
            return "edit-picture";
        }

        Picture existingPicture = pictureRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID картины: " + id));

        existingPicture.setHall(picture.getHall());
        existingPicture.setAuthor(picture.getAuthor());
        existingPicture.setName(picture.getName());
        existingPicture.setYear(picture.getYear());

        pictureRepository.save(existingPicture);
        return "redirect:/pictures";
    }

    @GetMapping("/delete/{id}")
    public String deletePicture(@PathVariable("id") long id, Model model) {
        Picture picture = pictureRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID картины: " + id));
        pictureRepository.delete(picture);
        return "redirect:/pictures";
    }
}

