package org.example.Museum.controller;

import org.example.Museum.entity.Role;
import org.example.Museum.entity.User;
import org.example.Museum.repository.RoleRepository;
import org.example.Museum.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.Set;

@Controller
@RequestMapping("/admin/users")
@PreAuthorize("hasRole('ADMIN')") // Обеспечивает доступ только администраторам
public class AdminUserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    /**
     * Показать список всех пользователей
     */
    @GetMapping
    public String listUsers(Model model) {
        List<User> users = userRepository.findAll();
        model.addAttribute("users", users);
        return "admin-users"; // Убедитесь, что шаблон находится по пути src/main/resources/templates/admin-users.html
    }

    /**
     * Назначить пользователю роль ADMIN
     */
    @PostMapping("/{id}/make-admin")
    @ResponseBody
    public ResponseEntity<?> makeAdmin(@PathVariable("id") Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.badRequest().body("{\"message\": \"Пользователь не найден\"}");
        }

        User user = optionalUser.get();
        Optional<Role> adminRoleOpt = roleRepository.findByName("ADMIN");
        if (adminRoleOpt.isEmpty()) {
            return ResponseEntity.status(500).body("{\"message\": \"Роль ADMIN не найдена\"}");
        }

        Role adminRole = adminRoleOpt.get();
        Set<Role> roles = user.getRoles();
        if (roles.contains(adminRole)) {
            return ResponseEntity.badRequest().body("{\"message\": \"Пользователь уже является администратором\"}");
        }

        roles.add(adminRole);
        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok("{\"message\": \"Пользователь назначен администратором\"}");
    }

    /**
     * Снять с пользователя роль ADMIN и назначить роль USER
     */
    @PostMapping("/{id}/remove-admin")
    @ResponseBody
    public ResponseEntity<?> removeAdmin(@PathVariable("id") Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.badRequest().body("{\"message\": \"Пользователь не найден\"}");
        }

        User user = optionalUser.get();
        Optional<Role> adminRoleOpt = roleRepository.findByName("ADMIN");
        Optional<Role> userRoleOpt = roleRepository.findByName("USER");

        if (adminRoleOpt.isEmpty() || userRoleOpt.isEmpty()) {
            return ResponseEntity.status(500).body("{\"message\": \"Роли ADMIN или USER не найдены\"}");
        }

        Role adminRole = adminRoleOpt.get();
        Role userRole = userRoleOpt.get();

        Set<Role> roles = user.getRoles();
        if (!roles.contains(adminRole)) {
            return ResponseEntity.badRequest().body("{\"message\": \"Пользователь не является администратором\"}");
        }

        roles.remove(adminRole);
        roles.add(userRole);
        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok("{\"message\": \"Роль ADMIN успешно снята\"}");
    }

    /**
     * Удалить пользователя
     */
    @DeleteMapping("/{id}")
    @ResponseBody
    public ResponseEntity<?> deleteUser(@PathVariable("id") Long userId) {
        Optional<User> optionalUser = userRepository.findById(userId);
        if (optionalUser.isEmpty()) {
            return ResponseEntity.badRequest().body("{\"message\": \"Пользователь не найден\"}");
        }

        User user = optionalUser.get();

        // Запрет на удаление самого себя
        String currentUsername = org.springframework.security.core.context.SecurityContextHolder.getContext().getAuthentication().getName();
        if (user.getUsername().equals(currentUsername)) {
            return ResponseEntity.badRequest().body("{\"message\": \"Нельзя удалить самого себя\"}");
        }

        userRepository.delete(user);
        return ResponseEntity.ok("{\"message\": \"Пользователь успешно удалён\"}");
    }
}
