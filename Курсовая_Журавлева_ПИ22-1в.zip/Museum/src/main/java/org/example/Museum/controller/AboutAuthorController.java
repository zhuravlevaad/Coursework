package org.example.Museum.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AboutAuthorController {

    @GetMapping("/aboutauthor")
    public String aboutAuthor() {
        return "aboutauthor";
    }
}