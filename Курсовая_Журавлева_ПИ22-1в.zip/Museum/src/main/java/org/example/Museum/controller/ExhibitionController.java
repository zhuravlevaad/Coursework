package org.example.Museum.controller;

import jakarta.validation.Valid;
import org.example.Museum.entity.Exhibition;
import org.example.Museum.repository.ExhibitionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.List;

@Controller
@RequestMapping("/exhibitions")
public class ExhibitionController {

    private final ExhibitionRepository exhibitionRepository;

    @Autowired
    public ExhibitionController(ExhibitionRepository exhibitionRepository) {
        this.exhibitionRepository = exhibitionRepository;
    }

    @GetMapping
    public String listExhibitions(Model model,
                                  @RequestParam(value = "search", required = false) String search,
                                  @RequestParam(value = "filter", required = false) String filter,
                                  @RequestParam(value = "service", required = false) String service) {
        List<Exhibition> exhibitions;

        // Поиск по различным параметрам
        if (search != null && !search.isEmpty()) {
            exhibitions = exhibitionRepository.findByNameContainingIgnoreCase(search);
        } else if (service != null && !service.isEmpty()) {
            exhibitions = exhibitionRepository.findByCuratorContainingIgnoreCase(service);
        } else {
            exhibitions = exhibitionRepository.findAll();
        }

        // Форматирование дат
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
        for (Exhibition exhibition : exhibitions) {
            exhibition.setFormattedStartdate(exhibition.getStartdate().format(formatter));
            exhibition.setFormattedFinishdate(exhibition.getFinishdate().format(formatter));
        }

        model.addAttribute("exhibitions", exhibitions);
        return "exhibitions";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("exhibition", new Exhibition());
        return "add-exhibition";
    }

    @PostMapping("/add")
    public String addExhibition(@Valid @ModelAttribute("exhibition") Exhibition exhibition, BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "add-exhibition";
        }
        exhibitionRepository.save(exhibition);
        return "redirect:/exhibitions";
    }

    @GetMapping("/edit/{id}")
    public String showUpdateForm(@PathVariable("id") long id, Model model) {
        Exhibition exhibition = exhibitionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID выставки: " + id));
        model.addAttribute("exhibition", exhibition);
        return "edit-exhibition";
    }

    @PostMapping("/update/{id}")
    public String updateExhibition(@PathVariable("id") long id, @Valid @ModelAttribute("exhibition") Exhibition exhibition,
                                   BindingResult result, Model model) {
        if (result.hasErrors()) {
            exhibition.setId(id);
            return "edit-exhibition";
        }

        Exhibition existingExhibition = exhibitionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID выставки: " + id));

        existingExhibition.setHall(exhibition.getHall());
        existingExhibition.setName(exhibition.getName());
        existingExhibition.setStartdate(exhibition.getStartdate());
        existingExhibition.setFinishdate(exhibition.getFinishdate());
        existingExhibition.setCurator(exhibition.getCurator());
        existingExhibition.setAuthors(exhibition.getAuthors());

        exhibitionRepository.save(existingExhibition);
        return "redirect:/exhibitions";
    }

    @GetMapping("/delete/{id}")
    public String deleteExhibition(@PathVariable("id") long id, Model model) {
        Exhibition exhibition = exhibitionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Неверный ID выставки: " + id));
        exhibitionRepository.delete(exhibition);
        return "redirect:/exhibitions";
    }
}
